Corporation Logos 1.0.2 for EVEJS Launcher
================================================

Install
  1. Stop Game in EVEJS Launcher.
  2. Mods > Import, and choose this ZIP.
  3. Enable Corporation Logos, then start Game.

Give a corporation a logo
  Double-click Set-Corporation-Logo.cmd in the mod's folder and answer the
  questions (EveJS folder, corporation ID, image), or use the Playerbots
  dashboard's Logo panel if you run Playerbots. Players see a logo from their
  next login.

Disable or Remove in the launcher puts the EveJS files back; the logo images
are kept. Full instructions: README.md in the full release, or
https://github.com/ubermidas/evejs-corporation-logos
